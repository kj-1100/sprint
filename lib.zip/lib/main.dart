import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:sprint/firebase_options.dart';
import 'package:sprint/home/home_page.dart';
import 'package:sprint/login_or_register/login_page.dart';
import 'package:sprint/login_or_register/register_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Inicialize o Firebase App com as opções da sua aplicação Firebase Web:
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  // Aguarda o Firebase carregar o estado de autenticação persistido
  User? usuarioAtual = await FirebaseAuth.instance.authStateChanges().first;

  // Define a rota inicial com base no login persistido
  String initialRoute;
  if (usuarioAtual != null) {
    initialRoute = '/home';
  } else {
    initialRoute = '/login';
  }

  runApp(MyApp(initialRoute: initialRoute));
}

class MyApp extends StatelessWidget {
  final String initialRoute;
  const MyApp({super.key, required this.initialRoute});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Firebase Auth Demo',
      // Define a rota inicial dinamicamente (login ou home)
      initialRoute: initialRoute,
      routes: {
        '/login': (context) => const LoginPage(),
        '/register': (context) => const RegisterPage(),
        '/home': (context) => const HomePage(),
      },
      // Podemos definir a tela de login como rota padrão para qualquer rota desconhecida:
      onUnknownRoute: (settings) =>
          MaterialPageRoute(builder: (_) => const LoginPage()),
    );
  }
}
