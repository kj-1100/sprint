import 'package:flutter/material.dart';
import 'dart:io';
import 'package:image_picker/image_picker.dart';

class BudgetDetailPage extends StatefulWidget {
  final Map<String, dynamic> budget;
  const BudgetDetailPage({super.key, required this.budget});

  @override
 State<BudgetDetailPage>  createState() => _BudgetDetailPageState();
}

class _BudgetDetailPageState extends State<BudgetDetailPage> {
  final TextEditingController _itemController = TextEditingController();
  final TextEditingController _priceController = TextEditingController();
  final TextEditingController _supplierController = TextEditingController();
  File? _image;

  Future<void> _pickImage() async {
    final pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  void _addItem() {
    if (_itemController.text.isNotEmpty && _priceController.text.isNotEmpty && _supplierController.text.isNotEmpty) {
      setState(() {
        widget.budget['items'].add({
          'item': _itemController.text,
          'price': _priceController.text,
          'supplier': _supplierController.text,
          'image': _image
        });
        _itemController.clear();
        _priceController.clear();
        _supplierController.clear();
        _image = null;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.budget['name'])),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _itemController,
              decoration: const InputDecoration(labelText: 'Item'),
            ),
            TextField(
              controller: _priceController,
              decoration: const InputDecoration(labelText: 'Preço'),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: _supplierController,
              decoration: const InputDecoration(labelText: 'Fornecedor'),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: _pickImage,
              child: const Text('Selecionar Imagem'),
            ),
            const SizedBox(height: 10),
            _image != null ? Image.file(_image!, height: 100) : const SizedBox(),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: _addItem,
              child: const Text('Adicionar Item'),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: widget.budget['items'].length,
                itemBuilder: (context, index) {
                  final item = widget.budget['items'][index];
                  return ListTile(
                    title: Text(item['item']),
                    subtitle: Text('R\$ ${item['price']} - Fornecedor: ${item['supplier']}'),
                    leading: item['image'] != null ? Image.file(item['image'], width: 50, height: 50) : null,
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}