import 'package:flutter/material.dart';
import 'budget_detail_page.dart';

class BudgetPage extends StatefulWidget {
  const BudgetPage({super.key});

  @override
 State<BudgetPage>   createState() => _BudgetPageState();
}

class _BudgetPageState extends State<BudgetPage> {
  final TextEditingController _budgetController = TextEditingController();
  final List<Map<String, dynamic>> _budgets = [];

  void _createBudget() {
    if (_budgetController.text.isNotEmpty) {
      setState(() {
        _budgets.add({
          'name': _budgetController.text,
          'items': []
        });
        _budgetController.clear();
      });
    }
  }

  void _openBudget(int index) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => BudgetDetailPage(budget: _budgets[index]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Gestão de Orçamentos')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _budgetController,
              decoration: const InputDecoration(labelText: 'Nome do Orçamento'),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: _createBudget,
              child: const Text('Criar Orçamento'),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: _budgets.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(_budgets[index]['name']),
                    onTap: () => _openBudget(index),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}