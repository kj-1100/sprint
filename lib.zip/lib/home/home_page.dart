import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:multi_split_view/multi_split_view.dart';
import 'package:sprint/home/budgets/budget_detail_page.dart';
import 'package:sprint/home/budgets/budget_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _multiViewController = MultiSplitViewController(
      areas: [Area(size: 280, min: 0.1), Area(min: 500)]);
  User? _usuario;

  @override
  void initState() {
    super.initState();
    _usuario = FirebaseAuth.instance.currentUser;
    // Proteção de rota: se não houver usuário logado, redireciona para Login
    if (_usuario == null) {
      // Remove todas as rotas anteriores e vai para login
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
      });
    }
  }

  @override
  void dispose() {
    _multiViewController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Caso _usuario seja null, podemos retornar uma tela vazia temporária
    // (o redirecionamento acontecerá em initState).
    if (_usuario == null) {
      return const Scaffold();
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Home'),
        actions: [
          IconButton(onPressed: _logout, icon: const Icon(Icons.logout)),
        ],
      ),
      body: MultiSplitViewTheme(
        data: MultiSplitViewThemeData(
            dividerPainter: DividerPainters.background(
                color: Colors.amber, highlightedColor: Colors.pink)),
        child: MultiSplitView(
          controller: _multiViewController,
          builder: (context, area) => area.index == 0
              ? BudgetPage()
              : const BudgetDetailPage(budget: {},),
        ),
      ),
    );
  }

  Future<void> _logout() async {
    await FirebaseAuth.instance.signOut();
    // Após logout, redireciona para tela de login removendo histórico
    if (mounted) {
      Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
    }
  }
}
